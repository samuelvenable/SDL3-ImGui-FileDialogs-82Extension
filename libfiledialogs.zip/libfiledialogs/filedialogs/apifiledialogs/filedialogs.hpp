/*

 MIT License

 Copyright © 2021-2026 Samuel Venable

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.

*/

#pragma once

#include <string>

#include <SDL3/SDL.h>

namespace ngs::im {

  void ifd_load_fonts();
  std::string show_message(std::string message);
  std::string show_question(std::string message);
  std::string show_question_ext(std::string message);
  std::string get_string(std::string message, std::string value);
  double get_number(std::string message, double value);
  std::string get_open_filename(std::string filter, std::string fname);
  std::string get_open_filename_ext(std::string filter, std::string fname, std::string dir, std::string title);
  std::string get_open_filenames(std::string filter, std::string fname);
  std::string get_open_filenames_ext(std::string filter, std::string fname, std::string dir, std::string title);
  std::string get_save_filename(std::string filter, std::string fname);
  std::string get_save_filename_ext(std::string filter, std::string fname, std::string dir, std::string title);
  std::string get_directory(std::string dname);
  std::string get_directory_alt(std::string capt, std::string root);

} // namespace ngs::im

#ifdef _WIN32
#define EXPORTED_FUNCTION extern "C" __declspec(dllexport)
#else
#define EXPORTED_FUNCTION extern "C" __attribute__((visibility("default")))
#endif
EXPORTED_FUNCTION char *ifd_get_parent();
EXPORTED_FUNCTION double ifd_set_parent(char *winid);
EXPORTED_FUNCTION double ifd_load_fonts(char *fnames, double size);
EXPORTED_FUNCTION char *ifd_get_font_fnames();
EXPORTED_FUNCTION double ifd_get_font_size();
EXPORTED_FUNCTION double ifd_get_showborder();
EXPORTED_FUNCTION double ifd_set_showborder(double show);
EXPORTED_FUNCTION double ifd_get_showinput();
EXPORTED_FUNCTION double ifd_set_showinput(double show);
EXPORTED_FUNCTION char *ifd_get_caption();
EXPORTED_FUNCTION double ifd_set_caption(char *str);
EXPORTED_FUNCTION double ifd_get_width();
EXPORTED_FUNCTION double ifd_set_width(double width);
EXPORTED_FUNCTION double ifd_get_height();
EXPORTED_FUNCTION double ifd_set_height(double height);
EXPORTED_FUNCTION double ifd_get_fullscreen();
EXPORTED_FUNCTION double ifd_set_fullscreen(double full);
EXPORTED_FUNCTION double ifd_get_embedded();
EXPORTED_FUNCTION double ifd_set_embedded(double embed);
EXPORTED_FUNCTION double ifd_get_cancelable();
EXPORTED_FUNCTION double ifd_set_cancelable(double cancel);
EXPORTED_FUNCTION char *ifd_get_theme();
EXPORTED_FUNCTION double ifd_set_theme(char *theme);
EXPORTED_FUNCTION double ifd_easy_theming_text_color(double red, double green, double blue);
EXPORTED_FUNCTION double ifd_easy_theming_head_color(double red, double green, double blue);
EXPORTED_FUNCTION double ifd_easy_theming_area_color(double red, double green, double blue);
EXPORTED_FUNCTION double ifd_easy_theming_body_color(double red, double green, double blue);
EXPORTED_FUNCTION double ifd_easy_theming_pops_color(double red, double green, double blue);
EXPORTED_FUNCTION double show_message(char *message);
EXPORTED_FUNCTION double show_question(char *message);
EXPORTED_FUNCTION double show_message_ext(char *message, char *button1, char *button2, char *button3);
EXPORTED_FUNCTION char *get_string(char *message, char *value);
EXPORTED_FUNCTION double get_integer(char *message, double value);
EXPORTED_FUNCTION char *get_open_filename(char *filter, char *fname);
EXPORTED_FUNCTION char *get_open_filename_ext(char *filter, char *fname, char *dir, char *title);
EXPORTED_FUNCTION char *get_open_filenames(char *filter, char *fname);
EXPORTED_FUNCTION char *get_open_filenames_ext(char *filter, char *fname, char *dir, char *title);
EXPORTED_FUNCTION char *get_save_filename(char *filter, char *fname);
EXPORTED_FUNCTION char *get_save_filename_ext(char *filter, char *fname, char *dir, char *title);
EXPORTED_FUNCTION char *get_directory(char *dname);
EXPORTED_FUNCTION char *get_directory_alt(char *capt, char *root);
EXPORTED_FUNCTION double ifd_localization_quick_access(char *str);
EXPORTED_FUNCTION double ifd_localization_this_pc(char *str);
EXPORTED_FUNCTION double ifd_localization_all_files(char *str);
EXPORTED_FUNCTION double ifd_localization_name(char *str);
EXPORTED_FUNCTION double ifd_localization_date_modified(char *str);
EXPORTED_FUNCTION double ifd_localization_size(char *str);
EXPORTED_FUNCTION double ifd_localization_new_file(char *str);
EXPORTED_FUNCTION double ifd_localization_new_directory(char *str);
EXPORTED_FUNCTION double ifd_localization_delete(char *str);
EXPORTED_FUNCTION double ifd_localization_are_you_sure(char *str);
EXPORTED_FUNCTION double ifd_localization_overwrite_file(char *str);
EXPORTED_FUNCTION double ifd_localization_enter_file_name(char *str);
EXPORTED_FUNCTION double ifd_localization_enter_directory_name(char *str);
EXPORTED_FUNCTION double ifd_localization_are_you_sure_you_want_to_delete(char *str);
EXPORTED_FUNCTION double ifd_localization_are_you_sure_you_want_to_overwrite(char *str);
EXPORTED_FUNCTION double ifd_localization_yes(char *str);
EXPORTED_FUNCTION double ifd_localization_no(char *str);
EXPORTED_FUNCTION double ifd_localization_ok(char *str);
EXPORTED_FUNCTION double ifd_localization_cancel(char *str);
EXPORTED_FUNCTION double ifd_localization_search(char *str);
EXPORTED_FUNCTION double ifd_localization_file_name_with_colon(char *str);
EXPORTED_FUNCTION double ifd_localization_file_name_without_colon(char *str);
EXPORTED_FUNCTION double ifd_localization_directory_name_with_colon(char *str);
EXPORTED_FUNCTION double ifd_localization_directory_name_without_colon(char *str);
EXPORTED_FUNCTION double ifd_localization_save(char *str);
EXPORTED_FUNCTION double ifd_localization_open(char *str);
